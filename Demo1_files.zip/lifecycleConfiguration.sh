#!/bin/bash
#!/bin/bash
eval "$(conda shell.bash hook)"
conda activate studio
pip install jupyterlab-s3-browser
jupyter serverextension enable --py jupyterlab_s3_browser

pip install amazon-codewhisperer-jupyterlab-ext~=1.0
jupyter server extension enable amazon-codewhisperer-jupyterlab-ext

echo 'This is a messgae confirming installation of Sagemaker Extension'

conda deactivate
restart-jupyter-server